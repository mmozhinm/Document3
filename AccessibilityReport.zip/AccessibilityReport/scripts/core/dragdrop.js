/* See license.txt for terms of usage */

/**
 * @module core/dragdrop
 */
define([
    "./object",
    "./events"
],

function(Obj, Events) {

// ********************************************************************************************* //

/**
 * @class Tracker
 * @param {Object} element
 * @param {Object} handle
 * @param {Object} callbacks onDragStart, onDragOver, onDragLeave, onDrop
 * @memberof module:core/dragdrop
 */
function Tracker(handle, callbacks)
{
    this.element = handle;
    this.handle = handle;
    this.callbacks = callbacks;

    this.cursorStartPos = null;
    this.cursorLastPos = null;
    //this.elementStartPos = null;
    this.dragging = false;

    // Start listening
    this.onDragStart = Obj.bind(this.onDragStart, this);
    this.onDragOver = Obj.bind(this.onDragOver, this);
    this.onDrop = Obj.bind(this.onDrop, this);

    Events.addEventListener(this.element, "mousedown", this.onDragStart, false);
    this.active = true;
}

/**
 * @lends module:core/dragdrop.Tracker.prototype
 */
var TrackerPrototype = {
    /**
     * @param {Event} event
     */
    onDragStart: function(event)
    {
        var e = Events.fixEvent(event);

        if (this.dragging)
            return;

        if (this.callbacks.onDragStart)
            this.callbacks.onDragStart(this);

        this.dragging = true;
        this.cursorStartPos = absoluteCursorPosition(e);
        this.cursorLastPos = this.cursorStartPos;
        //this.elementStartPos = new Position(
        //    parseInt(this.element.style.left),
        //    parseInt(this.element.style.top));

        Events.addEventListener(this.element.ownerDocument, "mousemove", this.onDragOver, false);
        Events.addEventListener(this.element.ownerDocument, "mouseup", this.onDrop, false);

        Events.cancelEvent(e);
    },

    /**
     * @param {Event} event
     */
    onDragOver: function(event)
    {
        if (!this.dragging)
            return;

        var e = Events.fixEvent(event);
        Events.cancelEvent(e);

        var newPos = absoluteCursorPosition(e);
        //newPos = newPos.Add(this.elementStartPos);
        newPos = newPos.Subtract(this.cursorStartPos);
        //newPos = newPos.Bound(lowerBound, upperBound);
        //newPos.Apply(this.element);

        // Only fire event if the position has been changed.
        if (this.cursorLastPos.x === newPos.x && this.cursorLastPos.y === newPos.y)
            return;

        if (typeof this.callbacks.onDragOver === "function")
        {
            this.callbacks.onDragOver(newPos, this);
            this.cursorLastPos = newPos;
        }

    },

    /**
     * @param {Event} event
     */
    onDrop: function(event)
    {
        if (!this.dragging)
            return;

        var e = Events.fixEvent(event);
        Events.cancelEvent(e);

        this.dragStop();
    },

    /**
     *
     */
    dragStop: function()
    {
        if (!this.dragging)
            return;

        Events.removeEventListener(this.element.ownerDocument, "mousemove", this.onDragOver, false);
        Events.removeEventListener(this.element.ownerDocument, "mouseup", this.onDrop, false);

        this.cursorStartPos = null;
        this.cursorLastPos = null;
        //this.elementStartPos = null;

        if (this.callbacks.onDrop !== null)
            this.callbacks.onDrop(this);

        this.dragging = false;
    },

    /**
     *
     */
    destroy: function()
    {
        Events.removeEventListener(this.element, "mousedown", this.onDragStart, false);
        this.active = false;

        if (this.dragging)
            this.dragStop();
    }
};

Tracker.prototype = TrackerPrototype;

// ********************************************************************************************* //

function Position(x, y)
{
    this.x = x;
    this.y = y;

    this.Add = function(val)
    {
        var newPos = new Position(this.x, this.y);
        if (val !== null && val !== undefined)
        {
            if(!isNaN(val.x))
                newPos.x += val.x;
            if(!isNaN(val.y))
                newPos.y += val.y;
        }
        return newPos;
    };

    this.Subtract = function(val)
    {
        var newPos = new Position(this.x, this.y);
        if (val !== null && val !== undefined)
        {
            if(!isNaN(val.x))
                newPos.x -= val.x;
            if(!isNaN(val.y))
                newPos.y -= val.y;
        }
        return newPos;
    };

    this.Bound = function(lower, upper)
    {
        var newPos = this.Max(lower);
        return newPos.Min(upper);
    };

    this.Check = function()
    {
        var newPos = new Position(this.x, this.y);
        if (isNaN(newPos.x))
            newPos.x = 0;

        if (isNaN(newPos.y))
            newPos.y = 0;

        return newPos;
    };

    this.Apply = function(element)
    {
        if (typeof(element) === "string")
            element = document.getElementById(element);

        if (!element)
            return;

        if(!isNaN(this.x))
            element.style.left = this.x + "px";

        if(!isNaN(this.y))
            element.style.top = this.y + "px";
    };
}

// ********************************************************************************************* //

function absoluteCursorPosition(e)
{
    if (isNaN(window.scrollX))
    {
        return new Position(e.clientX + document.documentElement.scrollLeft
            + document.body.scrollLeft, e.clientY + document.documentElement.scrollTop
            + document.body.scrollTop);
    }

    return new Position(e.clientX + window.scrollX, e.clientY + window.scrollY);
}

// ********************************************************************************************* //

/**
 * @alias module:core/dragdrop
 */
var DragDrop = {};

DragDrop.Tracker = Tracker;

return DragDrop;

// ********************************************************************************************* //
});
