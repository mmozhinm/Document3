/* See license.txt for terms of usage */

define(
{
    "root": {
        "homeTabLabel": "Home",
        "loadingHar": "Loading..."
    }
});
