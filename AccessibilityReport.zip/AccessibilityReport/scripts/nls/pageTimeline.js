/* See license.txt for terms of usage */

define(
{
    "root": {
        "pageLoad": "Page Load",
        "request": "Request",
        "requests": "Requests",
        "pageBarTooltip": "Click to select and include in statistics preview."
    }
});
